# AGENTS.md — Examen final de arquitectura de datos

## Contexto

Examen final con tiempo limitado. Hay que construir una arquitectura de datos con las herramientas del curso y después explicar el código y las decisiones. La fuente y el enunciado se entregan en el examen.

## Objetivo

Flujo vertical mínimo, real, probado y explicable. Primero funciona; después se mejora.

## Reglas

1. Leer el PDF antes de escribir código.
2. Resumir fuente, formato, frecuencia, volumen, latencia, salida y criterios.
3. Elegir Lambda o Medallion con justificación. No cambiar después.
4. Docker Compose para todo.
5. Sin datos inventados en la ruta principal.
6. Cero comentarios en el código.
7. Nombres claros, funciones pequeñas, archivos ordenados.
8. No borrar ni reescribir archivos ajenos sin autorización.
9. No commitear secretos.
10. Cada capa debe tener verificación real.
11. Probar el flujo completo antes de decir que terminó.
12. Entregar runbook, evidencia y explicación.

## Criterio de terminado

- `docker compose ps` sano.
- Un dato entra y sale.
- Hay filas/archivos/endpoint.
- Hay test o verificación reproducible.
- Cada archivo se puede explicar.
