---
name: examen-arquitectura
description: Construir y explicar una arquitectura de datos Lambda o Medallion en tiempo limitado, con Docker, Airflow, Kafka, MinIO, Spark, Postgres y API, priorizando un flujo vertical real, pruebas y código explicable.
---

# Skill: examen-arquitectura

## Principios

1. Leer el enunciado antes de tocar código.
2. Elegir arquitectura con justificación.
3. Construir un flujo vertical mínimo.
4. No inventar datos.
5. Cero comentarios.
6. No sobreingeniería.
7. Probar cada capa y el flujo completo.
8. Documentar comandos, puertos, endpoints y evidencia.

## Flujo

- Entender: fuente, formato, frecuencia, volumen, latencia, salida.
- Decidir: Lambda si hay batch + speed + reconciliación; Medallion si es batch-only.
- Construir: ingesta → storage → procesamiento → serving → API.
- Probar: health, dato real, filas/archivos, test, logs.
- Explicar: abrir archivo por archivo y mostrar el flujo.

## Reglas

- Sin comentarios.
- Sin secretos.
- Sin placeholders.
- Sin datos falsos en la ruta principal.
- Sin `git push` salvo pedido.
- Si algo falla: log, aislamiento, fix mínimo, re-test.
